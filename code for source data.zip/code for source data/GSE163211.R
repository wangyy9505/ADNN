rm(list = ls())
library(GEOquery)
library(Biobase)
# dir.create("GSE163211")
# 读取GEO中下载的SOFT formatted family file(s)
data <- getGEO(filename = "GSE163211/GSE163211_family.soft.gz", GSEMatrix = T)
# file.copy("GSE163211_family.soft.gz", "GSE163211/GSE163211_family.soft.gz")
# unlink("GSE163211_family.soft.gz")

# 使用GSMList函数提取每个样本GSM的信息
gsmlist <- GSMList(data)
# 使用GPLList函数提取所在平台GPL的信息, 并使用Table和$ID提取基因名称
probesets <- Table(GPLList(data)[[1]])$ID
# 将每个患者的表达谱整合在一起, 生成对应的matrix
data.matrix <- do.call('cbind',
                       lapply(gsmlist, function(x) {
                         tab <- Table(x)
                         mymatch <- match(probesets,tab$ID_REF)
                         return(tab$VALUE[mymatch])
                       }))
# 对基因表达值转换成numeric取log2
data.matrix <- apply(data.matrix, 2, function(x) {
  as.numeric(as.character(x))
})
data.matrix <- log2(data.matrix)
rownames(data.matrix) <- probesets
colnames(data.matrix) <- names(gsmlist)
data <- data.frame(t(data.matrix))

# 提取患者的临床信息
pdata <- data.frame()
for (gsm in gsmlist) {
  # 从gsm中不断向下索引得到患者的临床信息
  clin_vector <- gsm@header$characteristics_ch1
  # 将每个患者的数据收集并整理在一起
  clinical <- list()
  for (n in clin_vector) {
    cv <- strsplit(n, ": ", fixed = T)[[1]]
    clinical[cv[1]] <- cv[2]
  }
  pdata <- rbind(pdata, data.frame(clinical))
}
rownames(pdata) <- names(gsmlist)
write.csv(data, "GSE163211/GSE163211_Exp.csv")
write.csv(pdata, "GSE163211/GSE163211_Pheno.csv")
rm(list = ls())
