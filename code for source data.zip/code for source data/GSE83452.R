rm(list = ls())
library(GEOquery)
library(Biobase)
# dir.create("GSE83452")
# 读取GEO中下载的SOFT formatted family file(s)
data <- getGEO(filename = "GSE83452/GSE83452_family.soft.gz", GSEMatrix = T)
# file.copy("GSE83452_family.soft.gz", "GSE83452/GSE83452_family.soft.gz")
# unGSE83452link("GSE83452_family.soft.gz")
gene_table <- data@gpls$GPL16686@dataTable@table
gene_table <- gene_table[, c("ID", "GB_ACC")]
# 对GPL16686平台上的位点信息进行注释
library(clusterProfiler)
library(org.Hs.eg.db)
gene_id <- bitr(gene_table$GB_ACC, fromType = "ACCNUM", toType = "SYMBOL",
                OrgDb = org.Hs.eg.db)

genes <- merge(gene_table, gene_id, by.x = "GB_ACC", by.y = "ACCNUM", all.x = T)
genes <- genes[, c("ID", "SYMBOL")]

# 使用GSMList函数提取每个样本GSM的信息
gsmlist <- GSMList(data)
# 使用GPLList函数提取所在平台GPL的信息, 并使用Table和$ID提取基因名称
probesets <- Table(GPLList(data)[[1]])$ID
# 将每个患者的表达谱整合在一起, 生成对应的matrix
data.matrix <- do.call('cbind',
                       lapply(gsmlist, function(x) {
                         tab <- Table(x)
                         mymatch <- match(probesets, tab$ID_REF)
                         return(tab$VALUE[mymatch])
                       }))
# data.matrix中的基因表达量是经过log2 RMA处理之后的信号
data.matrix <- apply(data.matrix, 2, function(x) {
  as.numeric(as.character(x))
})

rownames(data.matrix) <- probesets
colnames(data.matrix) <- names(gsmlist)
data <- data.frame(data.matrix)
data <- data[order(rownames(data)), ]
genes <- genes[order(genes$ID), ]

data <- data[!is.na(genes$SYMBOL), ]
genes <- genes[!is.na(genes$SYMBOL), ]

data$symbol <- genes$SYMBOL
data <- data[, c(ncol(data), 1:(ncol(data) - 1))]

dup_gene <- data$symbol[duplicated(data$symbol)]
dup_index <- which(data$symbol %in% dup_gene)

unique_data <- data[-c(dup_index), ]

dup_data <- data[dup_index, ]
for (n in unique(dup_data$symbol)) {
  dat <- dup_data[dup_data$symbol == n, ]
  dat[1, 2:ncol(dat)] <- apply(dat[, 2:ncol(dat)], 2, mean)
  unique_data <- rbind(unique_data, dat[1, ])
}
rownames(unique_data) <- unique_data$symbol
data <- data.frame(t(unique_data[, -1]))
rm(list = ls()[-which(ls() %in% c("data", "gsmlist"))])
# 提取患者的临床信息
pdata <- data.frame()
for (gsm in gsmlist) {
  # 从gsm中不断向下索引得到患者的临床信息
  clin_vector <- gsm@header$characteristics_ch1
  # 将每个患者的数据收集并整理在一起
  clinical <- list()
  for (n in clin_vector) {
    cv <- strsplit(n, ": ", fixed = T)[[1]]
    clinical[cv[1]] <- cv[2]
  }
  pdata <- rbind(pdata, data.frame(clinical))
}
rownames(pdata) <- names(gsmlist)
rm(list = ls()[-which(ls() %in% c("data", "pdata"))])
write.csv(data, "GSE83452/GSE83452_Exp.csv")
write.csv(pdata, "GSE83452/GSE83452_Pheno.csv")
rm(list = ls())
