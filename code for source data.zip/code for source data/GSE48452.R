rm(list = ls())
library(GEOquery)
library(Biobase)
# dir.create("GSE48452")
# 读取GEO中下载的SOFT formatted family file(s)
data <- getGEO(filename = "GSE48452/GSE48452_family.soft.gz", GSEMatrix = T)
# file.copy("GSE48452_family.soft.gz", "GSE48452/GSE48452_family.soft.gz")
# unGSE48452link("GSE48452_family.soft.gz")
gene_table <- data@gpls$GPL11532@dataTable@table
gene_table <- gene_table[, c("ID", "gene_assignment")]

# 使用GSMList函数提取每个样本GSM的信息
gsmlist <- GSMList(data)
# 使用GPLList函数提取所在平台GPL的信息, 并使用Table和$ID提取基因名称
probesets <- Table(GPLList(data)[[1]])$ID
# 将每个患者的表达谱整合在一起, 生成对应的matrix
data.matrix <- do.call('cbind',
                       lapply(gsmlist, function(x) {
                         tab <- Table(x)
                         mymatch <- match(probesets, tab$ID_REF)
                         return(tab$VALUE[mymatch])
                       }))
data <- data.frame(data.matrix)

data$symbol <- gene_table$gene_assignment
data <- data[, c(ncol(data), 1:(ncol(data) - 1))]
data <- data[data$symbol != "---", ]
for (n in 1:nrow(data)) {
  data$symbol[n] <- strsplit(data$symbol[n], "//", fixed = T)[[1]][2]
}
data$symbol <- gsub(" ", "", data$symbol, fixed = T)
dup_gene <- data$symbol[duplicated(data$symbol)]
dup_index <- which(data$symbol %in% dup_gene)

unique_data <- data[-c(dup_index), ]

dup_data <- data[dup_index, ]
for (n in unique(dup_data$symbol)) {
  dat <- dup_data[dup_data$symbol == n, ]
  dat[1, 2:ncol(dat)] <- apply(dat[, 2:ncol(dat)], 2, mean)
  unique_data <- rbind(unique_data, dat[1, ])
}
rownames(unique_data) <- unique_data$symbol
data <- data.frame(t(unique_data[, -1]))
rm(list = ls()[-which(ls() %in% c("data", "gsmlist"))])
# 提取患者的临床信息
pdata <- NULL
for (gsm in gsmlist) {
  # 从gsm中不断向下索引得到患者的临床信息
  clin_vector <- gsm@header$characteristics_ch1
  clin_vector <- clin_vector[grep("group:", clin_vector, fixed = T)]
  # 将每个患者的数据收集并整理在一起
  cv <- strsplit(clin_vector, ": ", fixed = T)[[1]][2]
  pdata <- c(pdata, cv)
}
pdata <- data.frame(samp = names(gsmlist), group = pdata)
rm(list = ls()[-which(ls() %in% c("data", "pdata"))])
write.csv(pdata, "GSE48452/GSE48452_Pheno.csv")
write.csv(data, "GSE48452/GSE48452_Exp.csv")
rm(list = ls())
