rm(list = ls())
library(GEOquery)
library(Biobase)
# dir.create("GSE89632")
# 读取GEO中下载的SOFT formatted family file(s)
data <- getGEO(filename = "GSE89632/GSE89632_family.soft.gz", GSEMatrix = T)
gene_table <- data@gpls$GPL14951@dataTable@table
# file.copy("GSE89632_family.soft.gz", "GSE89632/GSE89632_family.soft.gz")
# unGSE89632link("GSE89632_family.soft.gz")
gene_table <- gene_table[, c("ID", "Symbol")]


# # 对GPL16686平台上的位点信息进行注释
# library(clusterProfiler)
# library(org.Hs.eg.db)
# gene_id <- bitr(gene_table$GB_ACC, fromType = "ACCNUM", toType = "SYMBOL",
#                 OrgDb = org.Hs.eg.db)
# 
# genes <- merge(gene_table, gene_id, by.x = "GB_ACC", by.y = "ACCNUM", all.x = T)
# genes <- genes[, c("ID", "SYMBOL")]

# 使用GSMList函数提取每个样本GSM的信息
gsmlist <- GSMList(data)
# 使用GPLList函数提取所在平台GPL的信息, 并使用Table和$ID提取基因名称
probesets <- Table(GPLList(data)[[1]])$ID
# 将每个患者的表达谱整合在一起, 生成对应的matrix
data.matrix <- do.call('cbind',
                       lapply(gsmlist, function(x) {
                         tab <- Table(x)
                         mymatch <- match(probesets, tab$ID_REF)
                         return(tab$VALUE[mymatch])
                       }))
data <- data.frame(data.matrix)
data$symbol <- gene_table$Symbol
data <- data[, c(ncol(data), 1:(ncol(data) - 1))]

dup_gene <- data$symbol[duplicated(data$symbol)]
dup_index <- which(data$symbol %in% dup_gene)

unique_data <- data[-c(dup_index), ]

dup_data <- data[dup_index, ]
for (n in unique(dup_data$symbol)) {
  dat <- dup_data[dup_data$symbol == n, ]
  dat[1, 2:ncol(dat)] <- apply(dat[, 2:ncol(dat)], 2, mean)
  unique_data <- rbind(unique_data, dat[1, ])
}
rownames(unique_data) <- unique_data$symbol
data <- data.frame(t(unique_data[, -1]))
rm(list = ls()[-which(ls() %in% c("data", "gsmlist"))])
# 提取患者的临床信息
pdata <- c()
for (gsm in gsmlist) {
  # 从gsm中不断向下索引得到患者的临床信息
  clin_vector <- gsm@header$characteristics_ch1
  clin_vector <- clin_vector[grep("diagnosis", clin_vector)]
  cv <- strsplit(clin_vector, ": ", fixed = T)[[1]][2]
  pdata <- c(pdata, cv)
}
pdata <- data.frame(samp = names(gsmlist), group = pdata)
rm(list = ls()[-which(ls() %in% c("data", "pdata"))])
write.csv(data, "GSE89632/GSE89632_Exp.csv")
write.csv(pdata, "GSE89632/GSE89632_Pheno.csv")
rm(list = ls())
